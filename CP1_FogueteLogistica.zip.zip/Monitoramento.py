from kit_dados import veiculos_logisticos, cargas, janelas_operacao, telemetria_pouso
import math

# Mostrar dados importantes dos veículos logistícos
def exibir_veiculos():
    maior_modelo = max(
        [len(veiculo['modelo']) for veiculo in veiculos_logisticos if veiculo['status'] == 'disponivel'],
        default=10,
    )
    largura_modelo = max(maior_modelo, 15)

    print(f'{"Veículos Disponiveis para Missão":^60}')
    print(f'{"=~" * 30}')
    print(
        f'{" Modelo":<{largura_modelo}}  | {"Carga Máxima":<14} | {"Combustível":<15}'
    )

    for veiculo in veiculos_logisticos:
        if veiculo['status'] == 'disponivel':
            print(
                f' {veiculo["modelo"]:<{largura_modelo}} |'
                f" {str(veiculo['carga_max_kg']) + ' Kg':<14} |"
                f" {str(veiculo['combustivel_pct']) + ' %':<15}"
            )
    print(f'{"=~" * 30}')

    print('\n' * 3)

# Mostrar dados importantes das cargas
def exibir_cargas():
    maior_carga = max(
        [len(carga['tipo']) for carga in cargas],
        default=10,
    )
    largura_carga = max(maior_carga, 15)

    cargas_ordenada = sorted(cargas, key=lambda carga: carga['prioridade'])

    print(f'{"Cargas Possíveis para Missão":^60}')
    print(f'{"=~" * 30}')
    print(f'{" Tipo":<{largura_carga}}  | {"Peso":<14}  | {"Prioridade":<15}')

    for carga in cargas_ordenada:    
        print(
            f' {carga['tipo']:<{largura_carga}} |'
            f' {str(carga['massa_kg']) + 'Kg':<15} | '
            f' {str(carga['prioridade'])}'
        )
    print(f'{"=~" * 30}')

    print('\n' * 3)

# Mostrar dados importantes das telemetria de pouso
# Mostrar dados importantes das telemetria de pouso
def exibir_telemetria():
    print(f'{"Telemetria de Pouso":^60}')
    print(f'{"=~" * 30}')
    print(f'{" Tempo":<10} | {"Altitude":<12} | {"Temp. Motor":<14} | {"Status":<12}')

    for dado in telemetria_pouso:
        if dado['temp_motor_c'] > 480 or dado['vibracao'] > 2.5:
            status = 'CRÍTICO'
        elif dado['temp_motor_c'] > 450 or dado['vibracao'] > 2.2:
            status = 'ALERTA'
        else:
            status = 'NORMAL'

        print(
            f' {str(dado["tempo_s"]) + "s":<9} |'
            f' {str(dado["altitude_m"]) + "m":<12} |'
            f' {str(dado["temp_motor_c"]) + "°C":<14} |'
            f' {status:<12}'
        )
    print(f'{"=~" * 30}')
    print('\n' * 3)


# Mostara dados importantes das janelas de operação
def exibir_janelas():
    janelas_ordenada = sorted(janelas_operacao, key=lambda janela: janela['prioridade'])

    print(f'{"Janelas Possíveis para Missão":^60}')
    print(f'{"=~" * 40}')
    print(f'{" Janela":<15}  | {"Risco":<14}  | {"Duração":<14}  | {"Prioridade":<15}')

    for janela in janelas_ordenada:    
        print(
            f' {janela['janela']:<15} |'
            f' {janela['risco']:<15} |'
            f' {str(janela['duracao_min']) + 'min':<15} | '
            f' {str(janela['prioridade'])}'
        )
    print(f'{"=~" * 40}')

    print('\n' * 3)


# Funções da Missão
# Função  1
def alocar_carga_no_veiculo(veiculo, carga):
    peso_carga = carga['massa_kg']
    carga_max_veiculo = veiculo['carga_max_kg']

    
    veiculo_carregado = {'modelo': veiculo['modelo'], 'carga_max_kg': veiculo['carga_max_kg'], 'carga_alocada': carga['massa_kg'], 'combustivel_pct': veiculo['combustivel_pct']}


    if carga_max_veiculo < peso_carga:
        relatorio = 'IMPOSSÍVEL ALOCAR'
    elif carga_max_veiculo - peso_carga <= carga_max_veiculo * 0.1:
        relatorio = 'CRITÍCO'
    elif carga_max_veiculo - peso_carga <= carga_max_veiculo * 0.16 :
        relatorio = 'ALERTA'
    else:
        relatorio = 'NORMAL'

    match relatorio:
        case 'IMPOSSÍVEL ALOCAR':
            grau_dificuldade = 10
        case 'CRITÍCO':
            grau_dificuldade = 3
        case 'ALERTA':
            grau_dificuldade = 2
        case 'NORMAL':
            grau_dificuldade = 1
    return grau_dificuldade, veiculo_carregado


# Função  2
def avaliar_viagem_por_local(veiculo, local_escolhido):
    peso_total_estimado = (veiculo['carga_max_kg'] * 100) / 4
    peso_estrutura = peso_total_estimado * 0.06
    combustivel_atual_kg = peso_total_estimado * 0.90 * (veiculo['combustivel_pct'] / 100)
    m_f = peso_estrutura + veiculo.get('carga_alocada', veiculo['carga_max_kg'])
    
    delta_v_pouso_orbita = 2200  
    isp = 316                     # Motor AJ10 NASA
    g0 = 9.80665
    
    combustivel_necessario_kg = m_f * (math.exp(delta_v_pouso_orbita / (isp * g0)) - 1)
    tem_combustivel = combustivel_atual_kg >= combustivel_necessario_kg

    potencia_lm_w = 1500  
    potencia_eva_w = 800  
    
    horas_totais = local_escolhido['horas_lm'] + local_escolhido['horas_eva']
    energia_necessaria_wh = (local_escolhido['horas_lm'] * potencia_lm_w) + (local_escolhido['horas_eva'] * potencia_eva_w)
    
    bateria_exigida_wh = (energia_necessaria_wh * 1.20) / 0.75
    bateria_disponivel_wh = veiculo.get('bateria_wh', 150000) 
    
    tem_bateria = bateria_disponivel_wh >= bateria_exigida_wh

    if not tem_combustivel or not tem_bateria:
        relatorio = 'IMPOSSÍVEL'
        grau_dificuldade = 10
    else:
        sobra_comb_pct = (combustivel_atual_kg - combustivel_necessario_kg) / combustivel_atual_kg
        if sobra_comb_pct <= 0.19:
            relatorio = 'CRÍTICO'
            grau_dificuldade = 3
        elif sobra_comb_pct <= 0.30:
            relatorio = 'ALERTA'
            grau_dificuldade = 2
        else:
            relatorio = 'NORMAL'
            grau_dificuldade = 1

    missao = {
        'local': local_escolhido['local'],
        'missao_ref': local_escolhido['missao'],
        'tempo_permanencia_h': horas_totais,
        'relatorio': relatorio,
        'combustivel_ok': tem_combustivel,
        'bateria_ok': tem_bateria
    }

    return missao, grau_dificuldade

def calcular_perigo_missao(grau_deficuldade_alocar_carga_veiculo, grau_dificuldade_local):
    grau_total_missao = grau_deficuldade_alocar_carga_veiculo + grau_dificuldade_local
    if grau_total_missao > 10:
        return 'MISSÂO CONDENADA'
    elif grau_total_missao > 6:
        return 'CRITÍCA'
    elif grau_total_missao > 3:
        return 'ALERTA'
    else:
        return 'NORMAL'
    
def diagnostico_geral():
    veiculos_disponiveis = [v for v in veiculos_logisticos if v['status'] == 'disponivel']
    carga_prioritaria = min(cargas, key=lambda c: c['prioridade'])
    janela_mais_segura = min(janelas_operacao, key=lambda j: j['prioridade'])

    print(f'{"Diagnóstico Geral da Operação":^60}')
    print(f'{"=~" * 30}')
    print(f' Veículos disponíveis: {len(veiculos_disponiveis)} de {len(veiculos_logisticos)}')
    print(f' Carga prioritária: {carga_prioritaria["tipo"]} ({carga_prioritaria["massa_kg"]} kg)')
    print(f' Janela mais segura: {janela_mais_segura["janela"]} (risco {janela_mais_segura["risco"]})')

    if len(veiculos_disponiveis) >= 3:
        status = 'NORMAL'
    elif len(veiculos_disponiveis) >= 1:
        status = 'ATENÇÃO'
    else:
        status = 'CRÍTICO'

    print(f' Status da operação: {status}')
    print(f'{"=~" * 30}')
    print('\n' * 3) 